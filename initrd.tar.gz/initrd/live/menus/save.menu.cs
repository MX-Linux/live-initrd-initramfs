   1)  Ano (předvolené)
   2)  Ne
