   1)  Domyślny
   2)  persist_all     Zapisz root w RAM, zapisz home na dysku (zapisz root podczas wyłączania)
   3)  persist_root    Zapisz root i home w RAM, następnie zapisywanie przy wyłączaniu
   4)  persist_static  Zapisz root i home na dysku, przy czym home osobno na dysku
   5)  p_static_root   Zapisz root i home razem na dysku
   6)  persist_home    Tylko home persistence
   7)  frugal_persist  Frugal z root w RAM i home na dysku
   8)  frugal_root     Frugal z root i home w RAM, następnie zapisywanie przy wyłączaniu
   9)  frugal_static   Frugal z root na dysku i home osobno na dysku
  10)  f_static_root   Frugal z root i home razem na dysku
  11)  frugal_home     Frugal tylko z home persistence
  12)  frugal_only     Tylko Frugal, bez persistence
