   1)  Předvolené
   2)  persist_all     Uložit root do RAM, uložit obsah home na disk (uložit root při vypnutí)
   3)  persist_root    Uložit root a home do RAM, následně uložit při vypnutí
   4)  persist_static  Uložit root a home na disk separátně
   5)  p_static_root   Uložit root a home společně na disk
   6)  persist_home    Pouze persistence Home
   7)  frugal_persist  Frugal s root v RAM a obsah home na disku
   8)  frugal_root     Frugal s root aj home v RAM, následně uložit změny při vypnutí
   9)  frugal_static   Frugal s root aj home na disku separátně
  10)  f_static_root   Frugal s root aj home na disku společně
  11)  frugal_home     Úsporný, s persistencí Home
  12)  frugal_only     Pouze úsporný, bez persistence
