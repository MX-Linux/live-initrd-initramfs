   1)  Domyślny
   2)  automount       Automatycznie montuj urządzenia po podłączeniu
   3)  noautomount     Wyłącz wszystkie dodatkowe montowania i automatyczne montowania
