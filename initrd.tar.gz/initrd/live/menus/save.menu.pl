   1)  Tak (domyślnie)
   2)  Nie
