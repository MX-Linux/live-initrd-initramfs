   1)  Domyślny
   2)  checkmd5        Sprawdź integralność nośnika live
   3)  checkfs         Sprawdź systemy plików LiveUSB i persistence ext2/3/4
   4)  toram           Skopiuj skompresowany system plików do pamięci RAM
   5)  i915_invert     Invert video on some Intel graphics systems
   6)  no_i915_invert  Disable Intel graphics invert
   7)  from=usb        Zakończ uruchamianie z LiveUSB
   8)  from=hd         Zakończ uruchamianie z dysku twardego
   9)  hwclock=ask     Poproś system, aby określił ustawienie zegara
  10)  hwclock=utc     Zegar sprzętowy używa UTC (tylko systemy Linux)
  11)  hwclock=local   Zegar sprzętowy wykorzystuje czas lokalny (systemy Windows)
  12)  password        Zmień hasła przed uruchomieniem
  13)  nostore         Wyłącz funkcję LiveUSB-Storage (tylko LiveUSB)
  14)  dostore         Włącz funkcję LiveUSB-Storage (tylko LiveUSB)
  15)  savestate       Zapisz niektóre pliki między ponownymi uruchomieniami (tylko LiveUSB)
  16)  nosavestate     Nie zapisuj plików między ponownymi uruchomieniami (tylko LiveUSB)
