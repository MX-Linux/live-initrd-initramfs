   1)  Předvolené
   2)  automount      Automaticky připojovat zařízení po vložení
   3)  noautomount     Zakázat všechna připojení a automatické připojování
