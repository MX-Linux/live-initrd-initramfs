   1)  Předvolené
   2)  checkmd5        Zkontrolovat integritu LIVE média
   3)  checkfs         Zkontrolovat LiveUSB a persistentní systémy ext2/3/4
   4)  toram           Zkopírovat komprimovaný soubor souborového systému do RAM
   5)  i915_invert     Invertovat video na některých Intel grafických systémech
   6)  no_i915_invert  Nepoužívat invert pro grafiky Intel
   7)  from=usb        Dokončit zavedení systému z LiveUSB
   8)  from=hd         Dokončit zavedení systému z pevného disku
   9)  hwclock=ask     Má systém pomoct určit nastavení hodin
  10)  hwclock=utc     Hardvérové hodiny používají UTC (pouze systémy Linux)
  11)  hwclock=local   Hardvérové hodiny používají lokální nastavení času (systémy MS Windows)
  12)  password        Před přihášením změnit hesla
  13)  nostore          Zakázat funkci uložiště LiveUSB (pouze LiveUSB)
  14)  dostore          Povolit funkci uložiště LiveUSB (pouzeLiveUSB)
  15)  savestate       Uchovávat soubory mezi restarty (pouze LiveUSB)
  16)  nosavestate     Neuchovávat soubory mezi restarty (pouze LiveUSB)
